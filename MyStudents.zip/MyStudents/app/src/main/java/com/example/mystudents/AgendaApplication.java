package com.example.mystudents;

import android.app.Application;

import com.example.mystudents.dao.AlunoDAO;
import com.example.mystudents.model.Aluno;

public class AgendaApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        AlunoDAO dao = new AlunoDAO();
        CriaAlunosTeste(dao);

    }

    private void CriaAlunosTeste(AlunoDAO dao) {
        dao.salva(new Aluno("Dasha", "99283910", "DashaLoveOfMyLife@myLove.com"));
        dao.salva(new Aluno("Dasha2", "99283910", "DashaLoveOfMyLife@myLove.com"));
    }
}
